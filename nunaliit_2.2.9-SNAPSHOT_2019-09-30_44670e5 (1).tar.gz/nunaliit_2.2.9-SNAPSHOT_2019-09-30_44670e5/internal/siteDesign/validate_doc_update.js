function(newDoc, oldDoc, userCtxt) {

	// Accept everything
}