/*
Copyright (c) 2010, Geomatics and Cartographic Research Centre, 
Carleton University, Canada
All rights reserved.

Released under New BSD License.
Details at:
   https://svn.gcrc.carleton.ca/nunaliit2/trunk/sdk/license.txt
*/

"use strict";

var nunaliit2;
(function(){
// Define here instead of n2.core.js
if( typeof nunaliit2 !== 'function' ){
	nunaliit2 = function(){};
	if( typeof window !== 'undefined' ){
		window.nunaliit2 = nunaliit2;
	};
};
if( typeof nunaliit2.coreScriptName === 'undefined' ){
	nunaliit2.coreScriptName = 'nunaliit2-couch-debug.js';
};
})();

