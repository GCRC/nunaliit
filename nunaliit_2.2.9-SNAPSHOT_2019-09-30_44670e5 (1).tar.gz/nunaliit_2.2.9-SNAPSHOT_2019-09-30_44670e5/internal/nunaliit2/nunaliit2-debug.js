/*
Copyright (c) 2010, Geomatics and Cartographic Research Centre, 
Carleton University, Canada
All rights reserved.

Released under New BSD License.
Details at:
   https://svn.gcrc.carleton.ca/nunaliit2/trunk/sdk/license.txt
*/

"use strict";
var nunaliit2;
(function(){
// Define here instead of n2.core.js
if( typeof nunaliit2 !== 'function' ){
	nunaliit2 = function(){};
	if( typeof window !== 'undefined' ){
		window.nunaliit2 = nunaliit2;
	};
};

var scriptLocation = null;
var pattern = new RegExp('(^|(.*?\/))nunaliit2-debug.js$');
var scripts = document.getElementsByTagName('script');
for( var loop=0; loop<scripts.length; ++loop ) {
	var src = scripts[loop].getAttribute('src');
	if (src) {
		var match = src.match(pattern);
		if( match ) {
			scriptLocation = match[1];
			break;
		}
	}
};
if( null === scriptLocation ) {
	alert('Unable to find library tag (nunaliit2-debug.js)');
};
if( typeof nunaliit2.coreScriptName === 'undefined' ){
	nunaliit2.coreScriptName = 'nunaliit2-debug.js';
};
var jsfiles = [
'handlebars.js'
,'tiles.js'
,'fileSaver.js'
,'papaparse.js'
,'n2.core.js'
,'n2.utils.js'
,'n2.cookie.js'
,'n2.scripts.js'
,'n2.css.js'
,'n2.class.js'
,'n2.error.js'
,'n2.crypto.sha1.js'
,'n2.storage.js'
,'n2.indexedDb.js'
,'n2.debug.js'
,'n2.url.js'
,'n2.csv.js'
,'n2.jquery.js'
,'n2.l10n.js'
,'n2.interval.js'
,'n2.date.js'
,'n2.dateService.js'
,'n2.base64.js'
,'n2.blindWidget.js'
,'n2.help.js'
,'n2.docFnCall.js'
,'n2.schema.js'
,'n2.dispatch.js'
,'n2.logger.js'
,'n2.geometry.js'
,'n2.analytics.js'
,'n2.custom.js'
,'n2.customType.js'
,'n2.history.js'
,'n2.tree.js'
,'n2.slideEditor.js'
,'n2.form.js'
,'n2.displayBox.js'
,'n2.displayTiledImage.js'
,'n2.mediaDisplay.js'
,'n2.photosphere.js'
,'n2.googleDocs.js'
,'n2.dbSearchEngine.js'
,'n2.contributionDb.js'
,'n2.upload.js'
,'n2.olFixes.js'
,'n2.olBBOX.js'
,'n2.olFilter.js'
,'n2.olStyleMapCallback.js'
,'n2.olUtils.js'
,'n2.olLoadingControl.js'
,'n2.olLayerSwitcher.js'
,'n2.olFeatureHandler.js'
,'n2.olGenericControl.js'
,'n2.olFeatureStrategy.js'
,'n2.olModelProtocol.js'
,'n2.olMap.js'
,'n2.sliderWithCallout.js'
,'n2.timelineDateMarks.js'
,'n2.progress.js'
,'jquery-progress-1.0.js'
,'jquery-progress-slide-1.0.js'
,'comet/json2.js'
,'comet/jquery.cometd.js'
,'jquery.auth-cookie.js'
,'dbweb.js'
,'n2.mapAndControls.js'
,'n2.mapStyles.js'
,'n2.mapInitialBounds.js'
,'n2.mapUtilities.js'
,'patcher.js'
,'n2.GeoJsonGeometryCompressor.js'
,'n2.GeoJsonFeatureCoordinatesProcessor.js'
,'n2.languageSupport.js'
,'n2.GeoNames.js'
,'n2.document.js'
,'n2.objectSelector.js'
,'n2.userIntentView.js'
,'n2.styleRuleParser.js'
,'n2.styleRule.js'
,'n2.svg.js'
,'n2.mail.js'
,'n2.instance.js'
,'n2.model.js'
,'n2.modelFilter.js'
,'n2.modelFilterSimultaneous.js'
,'n2.modelUtils.js'
,'n2.modelTime.js'
,'n2.modelLayer.js'
,'n2.widgetBasic.js'
,'n2.widgetWait.js'
,'n2.widgetSplash.js'
,'n2.widgetTime.js'
,'n2.widgetPolarStereographicProjectionSelector.js'
,'n2.widgetBookBrowser.js'
,'n2.widgetNavigation.js'
,'n2.widgetLayer.js'
,'n2.widgetSelectableFilter.js'
,'n2.widgetExport.js'
,'n2.widgetModelBrowser.js'
,'n2.widgetLegend.js'
,'n2.widgetCollapsibleContainer.js'
,'n2.widgetResizingContainer.js'
,'n2.widgetDuplicate.js'
,'n2.widgetTranscript.js'
,'n2.canvas.js'
,'n2.canvasElementGenerator.js'
,'n2.canvasForceGraph.js'
,'n2.canvasRadial.js'
,'n2.canvasRadialTree.js'
,'n2.canvasCollapsibleRadialTree.js'
,'n2.canvasGrid.js'
,'n2.canvasPack.js'
,'n2.canvasTree.js'
,'n2.canvasCustomHTML.js'
,'n2.canvasCustomSVG.js'
,'n2.canvasReferenceBrowser.js'
,'n2.canvasTable.js'
,'n2.canvasVerticalTimeline.js'
,'n2.canvasMap.js'
,'n2.display.js'
,'n2.displayRibbon.js'
,'n2.displayRibbon2.js'
,'n2.comment.js'
,'n2.zoomify.js'
,'n2.html.js'
,'n2.wiki.js'
,'n2.tuioclient.js'
,'n2.utilities.js'
,'n2.utilitiesModel.js'
,'n2.utilitiesChangeDetectors.js'
,'n2.couch.js'
,'n2.couch.indexedDb.js'
,'n2.couchUtils.js'
,'n2.couchTiles.js'
,'n2.couchSchema.js'
,'n2.couchImportData.js'
,'n2.couchConfiguration.js'
,'n2.couchGeom.js'
,'n2.couchShow.js'
,'n2.couchEdit.js'
,'n2.couchRelatedDoc.js'
,'n2.couchDisplay.js'
,'n2.couchDisplayTiles.js'
,'n2.couchSearch.js'
,'n2.couchDialogs.js'
,'n2.couch.ol.js'
,'n2.couch.l10n.js'
,'n2.couchMap.js'
,'n2.couchRequests.js'
,'n2.couch.sound.js'
,'n2.couchAuth.js'
,'n2.couchModule.js'
,'n2.couchNavigation.js'
,'n2.couchExport.js'
,'n2.couchDispatchSupport.js'
,'n2.couchEvents.js'
,'n2.couchUser.js'
,'n2.couchHelp.js'
,'n2.couchDocument.js'
,'n2.couchDocumentList.js'
,'n2.couchAttachment.js'
,'n2.couchDisplayBox.js'
,'n2.couchImportProfile.js'
,'n2.couchImportProfileOperation.js'
,'n2.couchDbPerspective.js'
,'n2.couchSimplifiedGeometries.js'
];
var allScriptTags = new Array();
for( var i=0; i<jsfiles.length; ++i ) {
	allScriptTags.push('<script src="');
	allScriptTags.push(scriptLocation);
	allScriptTags.push(jsfiles[i]);
	allScriptTags.push('"></script>');
};
document.write(allScriptTags.join(''));
})();
