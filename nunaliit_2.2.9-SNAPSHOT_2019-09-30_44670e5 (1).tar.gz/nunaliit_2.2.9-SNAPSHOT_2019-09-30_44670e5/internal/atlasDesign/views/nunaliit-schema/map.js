function(doc) {
	if( doc.nunaliit_schema ) {
		emit(doc.nunaliit_schema,null);
	};
}
